#include "linkedList.h"
#define FNAMEHT "disk.txt"
#define FNAMELL "llist.txt"

FILE *file_ht;
FILE *file_ll;

void exit_FMTTM();
void enter_FMTTM();
void openTable_FMTTM();